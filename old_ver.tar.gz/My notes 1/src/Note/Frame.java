//***************
//*DovgaNik 20!8*
//***************
package Note;

import java.io.*;

public class Frame extends javax.swing.JFrame {
public Frame() {
        initComponents();
        read_method();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jB_Clean = new javax.swing.JButton();
        jB_Write = new javax.swing.JButton();
        jB_Read = new javax.swing.JButton();
        jL_Out = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jT_Note = new javax.swing.JTextArea();
        jB_Info = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList_Notes = new javax.swing.JList<>();
        jTextField_NewItem = new javax.swing.JTextField();
        jButton_Create = new javax.swing.JButton();
        jButton_Delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Note");
        setName("Note"); // NOI18N
        setResizable(false);

        jB_Clean.setText("Clean");
        jB_Clean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_CleanActionPerformed(evt);
            }
        });

        jB_Write.setText("Write");
        jB_Write.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_WriteActionPerformed(evt);
            }
        });

        jB_Read.setText("Read");
        jB_Read.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ReadActionPerformed(evt);
            }
        });

        jT_Note.setColumns(20);
        jT_Note.setRows(5);
        jScrollPane1.setViewportView(jT_Note);

        jB_Info.setText("Info");
        jB_Info.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_InfoActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(jList_Notes);

        jButton_Create.setText("Create");
        jButton_Create.setToolTipText("");
        jButton_Create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_CreateActionPerformed(evt);
            }
        });

        jButton_Delete.setText("Delete");
        jButton_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_DeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton_Create, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(jTextField_NewItem, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jButton_Delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jB_Clean)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jB_Write)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jB_Read)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jL_Out, javax.swing.GroupLayout.DEFAULT_SIZE, 746, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jB_Info)
                .addGap(6, 6, 6))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField_NewItem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton_Create)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton_Delete)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jB_Clean)
                        .addComponent(jB_Write)
                        .addComponent(jB_Read))
                    .addComponent(jL_Out, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jB_Info, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jB_CleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_CleanActionPerformed
        //Cleaning the text fild
        jL_Out.setText("Cleaning...");
        jT_Note.setText(null);
    }//GEN-LAST:event_jB_CleanActionPerformed

    private void jB_WriteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_WriteActionPerformed
        //Wiriting to file
        jL_Out.setText("Writing to file...");
        //String txt = jT_Note.getText();
        //String line = null;
        try{
        FileWriter write = new FileWriter("note");
        BufferedWriter buffer = new BufferedWriter(write);
        buffer.write(jT_Note.getText());
        buffer.close();
        }catch(IOException ex){
            jL_Out.setText("Writing error!!!! (IOException) :-(");
        }
    }//GEN-LAST:event_jB_WriteActionPerformed

    private void jB_ReadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ReadActionPerformed
        //Readingfrom the file
        jL_Out.setText("Reading from file...");
        read_method();
    }//GEN-LAST:event_jB_ReadActionPerformed

    public void read_method(){
        String txt = "";
        String line = null;
            try {
                FileReader read = new FileReader("note");
                BufferedReader buffer = new BufferedReader(read);
                while((line = buffer.readLine()) != null){
                    txt = txt + line + "\n";
                }
                buffer.close();
            } catch (FileNotFoundException ex) {
                jL_Out.setText("Reading error!!!! (File not found) :-(");
            }
            catch(IOException ex){
                jL_Out.setText("Reading error!!!! (IOException) :-(");
            }
        jT_Note.setText(txt);
    }
    
    private void jB_InfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_InfoActionPerformed
        //Info
        jL_Out.setText("Loading information...");
        jT_Note.setText("\t\t\tCopyright DovgaNik 2018©\n\n\t\t\t        Version:1.0.2.2\n" + "Changelog: \n\n" + 
                "1.0.0.1:\n Added info button;\n\n1.0.1.1:\nFixed bug with 'null';\nFixed bug with lines;\n\n1.0.1.2:\nAdded changelog;\n\n1.0.2.2:\nAdd autoreading;\n\n");
    }//GEN-LAST:event_jB_InfoActionPerformed

    private void jButton_CreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_CreateActionPerformed
        //String[] Arr = jList_Notes;
    }//GEN-LAST:event_jButton_CreateActionPerformed

    private void jButton_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_DeleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton_DeleteActionPerformed

    
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
 


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_Clean;
    private javax.swing.JButton jB_Info;
    private javax.swing.JButton jB_Read;
    private javax.swing.JButton jB_Write;
    private javax.swing.JButton jButton_Create;
    private javax.swing.JButton jButton_Delete;
    private javax.swing.JLabel jL_Out;
    private javax.swing.JList<String[]> jList_Notes;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jT_Note;
    private javax.swing.JTextField jTextField_NewItem;
    // End of variables declaration//GEN-END:variables
}
